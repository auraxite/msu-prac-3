#!/usr/bin/env python3
a, b, c = map(int, input().split())
print(abs(a) + abs(b) + abs(c))
